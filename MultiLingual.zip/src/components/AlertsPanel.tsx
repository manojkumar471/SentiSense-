import React from 'react';
import { AlertTriangle, CheckCircle, Clock, X } from 'lucide-react';
import { Alert } from '../types/feedback';

interface AlertsPanelProps {
  alerts: Alert[];
  onResolveAlert: (alertId: string) => void;
  onDismissAlert: (alertId: string) => void;
}

export const AlertsPanel: React.FC<AlertsPanelProps> = ({ alerts, onResolveAlert, onDismissAlert }) => {
  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high': return 'border-red-500 bg-red-50 dark:bg-red-900/20';
      case 'medium': return 'border-yellow-500 bg-yellow-50 dark:bg-yellow-900/20';
      case 'low': return 'border-blue-500 bg-blue-50 dark:bg-blue-900/20';
      default: return 'border-gray-500 bg-gray-50 dark:bg-gray-900/20';
    }
  };

  const getSeverityIcon = (severity: string) => {
    const iconClass = severity === 'high' ? 'text-red-600' : severity === 'medium' ? 'text-yellow-600' : 'text-blue-600';
    return <AlertTriangle className={`w-5 h-5 ${iconClass}`} />;
  };

  const activeAlerts = alerts.filter(alert => !alert.resolved);
  const resolvedAlerts = alerts.filter(alert => alert.resolved);

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
          Alert Center
        </h3>
        <div className="flex space-x-2">
          <span className="px-2 py-1 bg-red-100 dark:bg-red-900/20 text-red-800 dark:text-red-400 text-xs rounded-full">
            {activeAlerts.length} Active
          </span>
          <span className="px-2 py-1 bg-green-100 dark:bg-green-900/20 text-green-800 dark:text-green-400 text-xs rounded-full">
            {resolvedAlerts.length} Resolved
          </span>
        </div>
      </div>

      <div className="space-y-4 max-h-96 overflow-y-auto">
        {activeAlerts.map((alert) => (
          <div
            key={alert.id}
            className={`p-4 rounded-lg border-l-4 ${getSeverityColor(alert.severity)} transition-all hover:shadow-md`}
          >
            <div className="flex items-start justify-between">
              <div className="flex items-start space-x-3">
                {getSeverityIcon(alert.severity)}
                <div className="flex-1">
                  <h4 className="font-medium text-gray-900 dark:text-white">
                    {alert.title}
                  </h4>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                    {alert.description}
                  </p>
                  <div className="flex items-center space-x-4 mt-2 text-xs text-gray-500 dark:text-gray-400">
                    <span className="flex items-center space-x-1">
                      <Clock className="w-3 h-3" />
                      <span>{alert.timestamp.toLocaleTimeString()}</span>
                    </span>
                    <span className="capitalize">
                      {alert.severity} priority
                    </span>
                  </div>
                </div>
              </div>
              
              <div className="flex space-x-2 ml-4">
                <button
                  onClick={() => onResolveAlert(alert.id)}
                  className="p-1 text-green-600 hover:bg-green-100 dark:hover:bg-green-900/20 rounded transition-colors"
                  title="Mark as resolved"
                >
                  <CheckCircle className="w-4 h-4" />
                </button>
                <button
                  onClick={() => onDismissAlert(alert.id)}
                  className="p-1 text-gray-600 hover:bg-gray-100 dark:hover:bg-gray-900/20 rounded transition-colors"
                  title="Dismiss alert"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        ))}

        {resolvedAlerts.slice(0, 3).map((alert) => (
          <div
            key={alert.id}
            className="p-4 rounded-lg border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900/20 opacity-60"
          >
            <div className="flex items-start space-x-3">
              <CheckCircle className="w-5 h-5 text-green-600" />
              <div className="flex-1">
                <h4 className="font-medium text-gray-900 dark:text-white line-through">
                  {alert.title}
                </h4>
                <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                  Resolved at {alert.timestamp.toLocaleTimeString()}
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {activeAlerts.length === 0 && (
        <div className="text-center py-8">
          <CheckCircle className="w-12 h-12 text-green-600 mx-auto mb-3" />
          <p className="text-gray-600 dark:text-gray-400">All alerts resolved!</p>
        </div>
      )}
    </div>
  );
};