import React, { useState, useEffect } from 'react';
import { Search, Filter, Download, RefreshCw, Moon, Sun, Zap } from 'lucide-react';
import { SentimentChart } from './SentimentChart';
import { LanguageDistribution } from './LanguageDistribution';
import { AlertsPanel } from './AlertsPanel';
import { ReviewCard } from './ReviewCard';
import { FeatureAnalysis } from './FeatureAnalysis';
import { ReviewProcessor } from './ReviewProcessor';
import { KeywordCloud, mockKeywords } from './KeywordCloud';
import { EmotionAnalysis } from './EmotionAnalysis';
import { mockReviews, sentimentTrends, languageStats, alerts as initialAlerts } from '../data/mockData';
import { Review, Alert } from '../types/feedback';
import { ProcessedReview } from '../services/nlpProcessor';

export const Dashboard: React.FC = () => {
  const [reviews, setReviews] = useState<Review[]>(mockReviews);
  const [alerts, setAlerts] = useState<Alert[]>(initialAlerts);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedLanguage, setSelectedLanguage] = useState('all');
  const [selectedSentiment, setSelectedSentiment] = useState('all');
  const [darkMode, setDarkMode] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [activeTab, setActiveTab] = useState<'overview' | 'processor' | 'analytics'>('overview');

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  const filteredReviews = reviews.filter(review => {
    const matchesSearch = review.comment.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         review.productName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         review.customerName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesLanguage = selectedLanguage === 'all' || review.languageCode === selectedLanguage;
    const matchesSentiment = selectedSentiment === 'all' || review.sentiment === selectedSentiment;
    
    return matchesSearch && matchesLanguage && matchesSentiment;
  });

  const handleResolveAlert = (alertId: string) => {
    setAlerts(alerts.map(alert => 
      alert.id === alertId ? { ...alert, resolved: true } : alert
    ));
  };

  const handleDismissAlert = (alertId: string) => {
    setAlerts(alerts.filter(alert => alert.id !== alertId));
  };

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await new Promise(resolve => setTimeout(resolve, 1500));
    setIsRefreshing(false);
  };

  const handleProcessedReview = (processedReview: ProcessedReview) => {
    // Convert processed review to our Review format and add to the list
    const newReview: Review = {
      id: `processed-${Date.now()}`,
      productId: 'processed-product',
      productName: 'Processed Product Review',
      customerName: 'AI Processed Customer',
      rating: processedReview.sentiment.score > 0 ? 5 : processedReview.sentiment.score < 0 ? 2 : 3,
      comment: processedReview.originalText,
      language: processedReview.detectedLanguage,
      languageCode: processedReview.languageCode,
      sentiment: processedReview.sentiment.label,
      sentimentScore: processedReview.sentiment.comparative,
      features: processedReview.features.map(f => ({
        feature: f.feature,
        sentiment: f.sentiment,
        score: f.score,
        mentions: f.mentions
      })),
      timestamp: new Date(),
      verified: false
    };

    setReviews(prev => [newReview, ...prev]);
  };

  const stats = {
    totalReviews: reviews.length,
    avgRating: (reviews.reduce((sum, review) => sum + review.rating, 0) / reviews.length).toFixed(1),
    positivePercentage: Math.round((reviews.filter(r => r.sentiment === 'positive').length / reviews.length) * 100),
    languages: new Set(reviews.map(r => r.language)).size
  };

  // Mock emotion data
  const mockEmotions = {
    joy: 0.35,
    anger: 0.15,
    fear: 0.08,
    sadness: 0.12,
    surprise: 0.20,
    disgust: 0.10
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors duration-200">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
                AI-Powered Feedback Analysis
              </h1>
              <div className="hidden sm:flex items-center space-x-2 text-sm text-gray-500 dark:text-gray-400">
                <span className="px-2 py-1 bg-blue-100 dark:bg-blue-900/20 text-blue-800 dark:text-blue-400 rounded-full">
                  {stats.totalReviews} Reviews
                </span>
                <span className="px-2 py-1 bg-green-100 dark:bg-green-900/20 text-green-800 dark:text-green-400 rounded-full">
                  {stats.positivePercentage}% Positive
                </span>
                <span className="px-2 py-1 bg-purple-100 dark:bg-purple-900/20 text-purple-800 dark:text-purple-400 rounded-full">
                  {stats.languages} Languages
                </span>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <button
                onClick={handleRefresh}
                disabled={isRefreshing}
                className="p-2 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors"
              >
                <RefreshCw className={`w-5 h-5 ${isRefreshing ? 'animate-spin' : ''}`} />
              </button>
              
              <button
                onClick={() => setDarkMode(!darkMode)}
                className="p-2 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors"
              >
                {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
              </button>

              <button className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                <Download className="w-4 h-4" />
                <span>Export</span>
              </button>
            </div>
          </div>

          {/* Navigation Tabs */}
          <div className="flex space-x-8 border-t border-gray-200 dark:border-gray-700">
            <button
              onClick={() => setActiveTab('overview')}
              className={`py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                activeTab === 'overview'
                  ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                  : 'border-transparent text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300'
              }`}
            >
              Overview Dashboard
            </button>
            <button
              onClick={() => setActiveTab('processor')}
              className={`py-4 px-1 border-b-2 font-medium text-sm transition-colors flex items-center space-x-2 ${
                activeTab === 'processor'
                  ? 'border-purple-500 text-purple-600 dark:text-purple-400'
                  : 'border-transparent text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300'
              }`}
            >
              <Zap className="w-4 h-4" />
              <span>AI Processor</span>
            </button>
            <button
              onClick={() => setActiveTab('analytics')}
              className={`py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                activeTab === 'analytics'
                  ? 'border-green-500 text-green-600 dark:text-green-400'
                  : 'border-transparent text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300'
              }`}
            >
              Advanced Analytics
            </button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'overview' && (
          <>
            {/* Search and Filters */}
            <div className="mb-8">
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <input
                    type="text"
                    placeholder="Search reviews, products, or customers..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                  />
                </div>
                
                <div className="flex space-x-3">
                  <select
                    value={selectedLanguage}
                    onChange={(e) => setSelectedLanguage(e.target.value)}
                    className="px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                  >
                    <option value="all">All Languages</option>
                    {languageStats.map(lang => (
                      <option key={lang.code} value={lang.code}>{lang.language}</option>
                    ))}
                  </select>
                  
                  <select
                    value={selectedSentiment}
                    onChange={(e) => setSelectedSentiment(e.target.value)}
                    className="px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                  >
                    <option value="all">All Sentiments</option>
                    <option value="positive">Positive</option>
                    <option value="neutral">Neutral</option>
                    <option value="negative">Negative</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Overview Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
              <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
                <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Total Reviews</h3>
                <p className="text-3xl font-bold text-gray-900 dark:text-white mt-2">{stats.totalReviews.toLocaleString()}</p>
              </div>
              <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
                <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Average Rating</h3>
                <p className="text-3xl font-bold text-gray-900 dark:text-white mt-2">{stats.avgRating} ⭐</p>
              </div>
              <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
                <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Positive Sentiment</h3>
                <p className="text-3xl font-bold text-green-600 mt-2">{stats.positivePercentage}%</p>
              </div>
              <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
                <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Languages Detected</h3>
                <p className="text-3xl font-bold text-blue-600 mt-2">{stats.languages}</p>
              </div>
            </div>

            {/* Main Dashboard Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
              <div className="lg:col-span-2">
                <SentimentChart data={sentimentTrends} />
              </div>
              <div>
                <LanguageDistribution data={languageStats} />
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
              <div className="lg:col-span-2">
                <FeatureAnalysis />
              </div>
              <div>
                <AlertsPanel 
                  alerts={alerts}
                  onResolveAlert={handleResolveAlert}
                  onDismissAlert={handleDismissAlert}
                />
              </div>
            </div>

            {/* Reviews Section */}
            <div className="mb-8">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
                  Recent Reviews ({filteredReviews.length})
                </h2>
                <div className="flex items-center space-x-2">
                  <Filter className="w-4 h-4 text-gray-500" />
                  <span className="text-sm text-gray-500 dark:text-gray-400">
                    Filtered by: {selectedLanguage !== 'all' && `${selectedLanguage.toUpperCase()}, `}
                    {selectedSentiment !== 'all' && `${selectedSentiment}, `}
                    {searchTerm && `"${searchTerm}"`}
                  </span>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredReviews.slice(0, 9).map((review) => (
                  <ReviewCard key={review.id} review={review} />
                ))}
              </div>
              
              {filteredReviews.length === 0 && (
                <div className="text-center py-12">
                  <p className="text-gray-500 dark:text-gray-400">No reviews match your current filters.</p>
                </div>
              )}
            </div>
          </>
        )}

        {activeTab === 'processor' && (
          <div className="space-y-8">
            <ReviewProcessor onProcessedReview={handleProcessedReview} />
            
            {/* Recent Processed Reviews */}
            <div>
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-6">
                Recently Processed Reviews
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {reviews
                  .filter(review => review.id.startsWith('processed-'))
                  .slice(0, 6)
                  .map((review) => (
                    <ReviewCard key={review.id} review={review} />
                  ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'analytics' && (
          <div className="space-y-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <KeywordCloud keywords={mockKeywords} />
              <EmotionAnalysis emotions={mockEmotions} totalReviews={reviews.length} />
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <SentimentChart data={sentimentTrends} />
              <FeatureAnalysis />
            </div>
          </div>
        )}
      </div>
    </div>
  );
};