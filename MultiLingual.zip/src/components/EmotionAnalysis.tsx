import React from 'react';
import { Heart, Frown, AlertTriangle, Smile, Zap, ThumbsDown } from 'lucide-react';
import { EmotionAnalysis as EmotionData } from '../services/nlpProcessor';

interface EmotionAnalysisProps {
  emotions: EmotionData;
  totalReviews: number;
}

export const EmotionAnalysis: React.FC<EmotionAnalysisProps> = ({ emotions, totalReviews }) => {
  const emotionConfig = [
    { key: 'joy', label: 'Joy', icon: Smile, color: 'text-yellow-600 bg-yellow-100 dark:bg-yellow-900/20' },
    { key: 'anger', label: 'Anger', icon: Frown, color: 'text-red-600 bg-red-100 dark:bg-red-900/20' },
    { key: 'fear', label: 'Fear', icon: AlertTriangle, color: 'text-orange-600 bg-orange-100 dark:bg-orange-900/20' },
    { key: 'sadness', label: 'Sadness', icon: ThumbsDown, color: 'text-blue-600 bg-blue-100 dark:bg-blue-900/20' },
    { key: 'surprise', label: 'Surprise', icon: Zap, color: 'text-purple-600 bg-purple-100 dark:bg-purple-900/20' },
    { key: 'disgust', label: 'Disgust', icon: Heart, color: 'text-green-600 bg-green-100 dark:bg-green-900/20' }
  ];

  const maxEmotion = Math.max(...Object.values(emotions));
  const dominantEmotion = Object.entries(emotions).reduce((a, b) => emotions[a[0] as keyof EmotionData] > emotions[b[0] as keyof EmotionData] ? a : b);

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-2">
          <Heart className="w-5 h-5 text-pink-600" />
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
            Emotion Analysis
          </h3>
        </div>
        <div className="text-right">
          <p className="text-sm text-gray-500 dark:text-gray-400">Dominant Emotion</p>
          <p className="font-medium text-gray-900 dark:text-white capitalize">
            {dominantEmotion[0]} ({(dominantEmotion[1] * 100).toFixed(1)}%)
          </p>
        </div>
      </div>

      <div className="space-y-4">
        {emotionConfig.map(({ key, label, icon: Icon, color }) => {
          const value = emotions[key as keyof EmotionData];
          const percentage = value * 100;
          const isHighest = value === maxEmotion && value > 0;

          return (
            <div
              key={key}
              className={`p-4 rounded-lg border transition-all ${
                isHighest 
                  ? 'border-2 border-pink-300 dark:border-pink-600 shadow-md' 
                  : 'border-gray-200 dark:border-gray-700'
              }`}
            >
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-3">
                  <div className={`p-2 rounded-lg ${color}`}>
                    <Icon className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-900 dark:text-white">
                      {label}
                      {isHighest && (
                        <span className="ml-2 px-2 py-1 bg-pink-100 dark:bg-pink-900/20 text-pink-600 text-xs rounded-full">
                          Dominant
                        </span>
                      )}
                    </h4>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      {percentage.toFixed(1)}% of emotional content
                    </p>
                  </div>
                </div>
                
                <div className="text-right">
                  <p className="text-lg font-bold text-gray-900 dark:text-white">
                    {Math.round(value * totalReviews)}
                  </p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">mentions</p>
                </div>
              </div>

              <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-3">
                <div
                  className={`h-3 rounded-full transition-all duration-500 ${
                    color.includes('yellow') ? 'bg-yellow-500' :
                    color.includes('red') ? 'bg-red-500' :
                    color.includes('orange') ? 'bg-orange-500' :
                    color.includes('blue') ? 'bg-blue-500' :
                    color.includes('purple') ? 'bg-purple-500' :
                    'bg-green-500'
                  }`}
                  style={{ width: `${percentage}%` }}
                />
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-6 pt-4 border-t border-gray-200 dark:border-gray-700">
        <div className="grid grid-cols-2 gap-4 text-center">
          <div className="p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
            <p className="text-2xl font-bold text-green-600">
              {((emotions.joy + emotions.surprise) * 100).toFixed(1)}%
            </p>
            <p className="text-sm text-green-700 dark:text-green-400">Positive Emotions</p>
          </div>
          <div className="p-3 bg-red-50 dark:bg-red-900/20 rounded-lg">
            <p className="text-2xl font-bold text-red-600">
              {((emotions.anger + emotions.fear + emotions.sadness + emotions.disgust) * 100).toFixed(1)}%
            </p>
            <p className="text-sm text-red-700 dark:text-red-400">Negative Emotions</p>
          </div>
        </div>
      </div>
    </div>
  );
};