import React from 'react';
import { BarChart3, TrendingUp, TrendingDown } from 'lucide-react';

interface FeatureData {
  name: string;
  positiveScore: number;
  negativeScore: number;
  mentions: number;
  trend: 'up' | 'down' | 'stable';
}

const mockFeatureData: FeatureData[] = [
  { name: 'Audio Quality', positiveScore: 87, negativeScore: 13, mentions: 245, trend: 'up' },
  { name: 'Battery Life', positiveScore: 45, negativeScore: 55, mentions: 198, trend: 'down' },
  { name: 'Comfort', positiveScore: 78, negativeScore: 22, mentions: 167, trend: 'stable' },
  { name: 'Design', positiveScore: 71, negativeScore: 29, mentions: 134, trend: 'up' },
  { name: 'Price Value', positiveScore: 62, negativeScore: 38, mentions: 189, trend: 'stable' },
  { name: 'Build Quality', positiveScore: 82, negativeScore: 18, mentions: 156, trend: 'up' }
];

export const FeatureAnalysis: React.FC = () => {
  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'up': return <TrendingUp className="w-4 h-4 text-green-600" />;
      case 'down': return <TrendingDown className="w-4 h-4 text-red-600" />;
      default: return <div className="w-4 h-4 bg-gray-400 rounded-full" />;
    }
  };

  const getTrendColor = (trend: string) => {
    switch (trend) {
      case 'up': return 'text-green-600';
      case 'down': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
      <div className="flex items-center space-x-2 mb-6">
        <BarChart3 className="w-5 h-5 text-blue-600" />
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
          Feature-wise Analysis
        </h3>
      </div>

      <div className="space-y-6">
        {mockFeatureData.map((feature) => (
          <div key={feature.name} className="p-4 rounded-lg border border-gray-200 dark:border-gray-700 hover:shadow-md transition-shadow">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center space-x-3">
                <h4 className="font-medium text-gray-900 dark:text-white">
                  {feature.name}
                </h4>
                <div className="flex items-center space-x-1">
                  {getTrendIcon(feature.trend)}
                  <span className={`text-sm ${getTrendColor(feature.trend)}`}>
                    {feature.trend}
                  </span>
                </div>
              </div>
              <span className="text-sm text-gray-500 dark:text-gray-400">
                {feature.mentions} mentions
              </span>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-green-600">Positive</span>
                <span className="font-medium">{feature.positiveScore}%</span>
              </div>
              <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                <div
                  className="bg-green-500 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${feature.positiveScore}%` }}
                />
              </div>

              <div className="flex items-center justify-between text-sm">
                <span className="text-red-600">Negative</span>
                <span className="font-medium">{feature.negativeScore}%</span>
              </div>
              <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                <div
                  className="bg-red-500 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${feature.negativeScore}%` }}
                />
              </div>
            </div>

            <div className="mt-3 pt-3 border-t border-gray-200 dark:border-gray-700">
              <div className="flex justify-between text-xs text-gray-500 dark:text-gray-400">
                <span>Overall Sentiment</span>
                <span className={feature.positiveScore > feature.negativeScore ? 'text-green-600' : 'text-red-600'}>
                  {feature.positiveScore > feature.negativeScore ? 'Positive' : 'Negative'}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};