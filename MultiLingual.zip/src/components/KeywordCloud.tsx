import React from 'react';
import { Hash, TrendingUp } from 'lucide-react';

interface KeywordData {
  word: string;
  frequency: number;
  sentiment: 'positive' | 'negative' | 'neutral';
  trend: 'up' | 'down' | 'stable';
}

interface KeywordCloudProps {
  keywords: KeywordData[];
}

export const KeywordCloud: React.FC<KeywordCloudProps> = ({ keywords }) => {
  const getSentimentColor = (sentiment: string) => {
    switch (sentiment) {
      case 'positive': return 'text-green-600 bg-green-100 dark:bg-green-900/20 border-green-200 dark:border-green-800';
      case 'negative': return 'text-red-600 bg-red-100 dark:bg-red-900/20 border-red-200 dark:border-red-800';
      case 'neutral': return 'text-yellow-600 bg-yellow-100 dark:bg-yellow-900/20 border-yellow-200 dark:border-yellow-800';
      default: return 'text-gray-600 bg-gray-100 dark:bg-gray-900/20 border-gray-200 dark:border-gray-800';
    }
  };

  const getFontSize = (frequency: number, maxFreq: number) => {
    const ratio = frequency / maxFreq;
    return `${0.8 + (ratio * 1.2)}rem`;
  };

  const maxFrequency = Math.max(...keywords.map(k => k.frequency));

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
      <div className="flex items-center space-x-2 mb-6">
        <Hash className="w-5 h-5 text-indigo-600" />
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
          Keyword Analysis
        </h3>
        <div className="flex items-center space-x-1 px-2 py-1 bg-indigo-100 dark:bg-indigo-900/20 rounded-full">
          <span className="text-xs text-indigo-600 font-medium">{keywords.length} terms</span>
        </div>
      </div>

      <div className="space-y-6">
        {/* Keyword Cloud */}
        <div className="p-4 bg-gray-50 dark:bg-gray-900/50 rounded-lg">
          <div className="flex flex-wrap gap-3 justify-center">
            {keywords.slice(0, 20).map((keyword, index) => (
              <div
                key={index}
                className={`px-3 py-2 rounded-lg border transition-all hover:scale-105 cursor-pointer ${getSentimentColor(keyword.sentiment)}`}
                style={{ fontSize: getFontSize(keyword.frequency, maxFrequency) }}
                title={`${keyword.word}: ${keyword.frequency} mentions, ${keyword.sentiment} sentiment`}
              >
                <div className="flex items-center space-x-1">
                  <span className="font-medium">{keyword.word}</span>
                  {keyword.trend === 'up' && <TrendingUp className="w-3 h-3" />}
                  {keyword.trend === 'down' && <TrendingUp className="w-3 h-3 rotate-180" />}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Top Keywords Table */}
        <div>
          <h4 className="font-medium text-gray-900 dark:text-white mb-3">Top Keywords</h4>
          <div className="space-y-2">
            {keywords.slice(0, 10).map((keyword, index) => (
              <div
                key={index}
                className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700 rounded-lg hover:shadow-md transition-shadow"
              >
                <div className="flex items-center space-x-3">
                  <span className="text-sm font-medium text-gray-500 dark:text-gray-400 w-6">
                    #{index + 1}
                  </span>
                  <span className="font-medium text-gray-900 dark:text-white">
                    {keyword.word}
                  </span>
                  <span className={`px-2 py-1 text-xs rounded-full ${getSentimentColor(keyword.sentiment)}`}>
                    {keyword.sentiment}
                  </span>
                </div>
                
                <div className="flex items-center space-x-4">
                  <div className="text-right">
                    <p className="text-sm font-medium text-gray-900 dark:text-white">
                      {keyword.frequency}
                    </p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">mentions</p>
                  </div>
                  
                  <div className="w-20 bg-gray-200 dark:bg-gray-600 rounded-full h-2">
                    <div
                      className="bg-indigo-600 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${(keyword.frequency / maxFrequency) * 100}%` }}
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Sentiment Distribution */}
        <div>
          <h4 className="font-medium text-gray-900 dark:text-white mb-3">Sentiment Distribution</h4>
          <div className="grid grid-cols-3 gap-4">
            {['positive', 'neutral', 'negative'].map(sentiment => {
              const count = keywords.filter(k => k.sentiment === sentiment).length;
              const percentage = (count / keywords.length) * 100;
              
              return (
                <div key={sentiment} className="text-center p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                  <p className={`text-2xl font-bold ${getSentimentColor(sentiment).split(' ')[0]}`}>
                    {count}
                  </p>
                  <p className="text-sm text-gray-600 dark:text-gray-400 capitalize">
                    {sentiment}
                  </p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    {percentage.toFixed(1)}%
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

// Mock data for demonstration
export const mockKeywords: KeywordData[] = [
  { word: 'quality', frequency: 156, sentiment: 'positive', trend: 'up' },
  { word: 'battery', frequency: 134, sentiment: 'negative', trend: 'down' },
  { word: 'sound', frequency: 128, sentiment: 'positive', trend: 'up' },
  { word: 'comfortable', frequency: 98, sentiment: 'positive', trend: 'stable' },
  { word: 'expensive', frequency: 87, sentiment: 'negative', trend: 'up' },
  { word: 'design', frequency: 76, sentiment: 'positive', trend: 'stable' },
  { word: 'broken', frequency: 65, sentiment: 'negative', trend: 'down' },
  { word: 'amazing', frequency: 54, sentiment: 'positive', trend: 'up' },
  { word: 'disappointed', frequency: 43, sentiment: 'negative', trend: 'stable' },
  { word: 'recommend', frequency: 89, sentiment: 'positive', trend: 'up' },
  { word: 'connection', frequency: 67, sentiment: 'neutral', trend: 'stable' },
  { word: 'durable', frequency: 45, sentiment: 'positive', trend: 'up' },
  { word: 'slow', frequency: 38, sentiment: 'negative', trend: 'down' },
  { word: 'perfect', frequency: 72, sentiment: 'positive', trend: 'up' },
  { word: 'issues', frequency: 56, sentiment: 'negative', trend: 'stable' }
];