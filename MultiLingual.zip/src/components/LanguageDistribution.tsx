import React from 'react';
import { Globe } from 'lucide-react';
import { LanguageStats } from '../types/feedback';

interface LanguageDistributionProps {
  data: LanguageStats[];
}

export const LanguageDistribution: React.FC<LanguageDistributionProps> = ({ data }) => {
  const getSentimentColor = (score: number) => {
    if (score > 0.6) return 'text-green-600';
    if (score > 0.3) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getSentimentBg = (score: number) => {
    if (score > 0.6) return 'bg-green-100 dark:bg-green-900/20';
    if (score > 0.3) return 'bg-yellow-100 dark:bg-yellow-900/20';
    return 'bg-red-100 dark:bg-red-900/20';
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
      <div className="flex items-center space-x-2 mb-6">
        <Globe className="w-5 h-5 text-blue-600" />
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
          Language Distribution
        </h3>
      </div>

      <div className="space-y-4">
        {data.map((lang) => (
          <div key={lang.code} className="flex items-center justify-between p-4 rounded-lg border border-gray-200 dark:border-gray-700 hover:shadow-md transition-shadow">
            <div className="flex items-center space-x-3">
              <div className="flex items-center space-x-2">
                <span className="text-2xl">{getFlagEmoji(lang.code)}</span>
                <div>
                  <p className="font-medium text-gray-900 dark:text-white">{lang.language}</p>
                  <p className="text-sm text-gray-500 dark:text-gray-400">{lang.count} reviews</p>
                </div>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="text-right">
                <p className="text-sm font-medium text-gray-900 dark:text-white">{lang.percentage}%</p>
                <div className="w-20 bg-gray-200 dark:bg-gray-700 rounded-full h-2 mt-1">
                  <div
                    className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${lang.percentage}%` }}
                  />
                </div>
              </div>
              
              <div className={`px-3 py-1 rounded-full text-xs font-medium ${getSentimentBg(lang.avgSentiment)}`}>
                <span className={getSentimentColor(lang.avgSentiment)}>
                  {(lang.avgSentiment * 100).toFixed(0)}% sentiment
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-6 pt-4 border-t border-gray-200 dark:border-gray-700">
        <div className="flex justify-between text-sm text-gray-600 dark:text-gray-400">
          <span>Total Reviews Analyzed</span>
          <span className="font-medium text-gray-900 dark:text-white">
            {data.reduce((sum, lang) => sum + lang.count, 0).toLocaleString()}
          </span>
        </div>
      </div>
    </div>
  );
};

function getFlagEmoji(countryCode: string): string {
  const flags: { [key: string]: string } = {
    'en': '🇺🇸',
    'es': '🇪🇸',
    'fr': '🇫🇷',
    'de': '🇩🇪',
    'ja': '🇯🇵',
    'ar': '🇸🇦'
  };
  return flags[countryCode] || '🌐';
}