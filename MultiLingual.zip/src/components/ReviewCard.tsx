import React from 'react';
import { Star, MessageSquare, CheckCircle, Globe } from 'lucide-react';
import { Review } from '../types/feedback';

interface ReviewCardProps {
  review: Review;
}

export const ReviewCard: React.FC<ReviewCardProps> = ({ review }) => {
  const getSentimentColor = (sentiment: string) => {
    switch (sentiment) {
      case 'positive': return 'text-green-600 bg-green-100 dark:bg-green-900/20';
      case 'negative': return 'text-red-600 bg-red-100 dark:bg-red-900/20';
      case 'neutral': return 'text-yellow-600 bg-yellow-100 dark:bg-yellow-900/20';
      default: return 'text-gray-600 bg-gray-100 dark:bg-gray-900/20';
    }
  };

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`w-4 h-4 ${i < rating ? 'text-yellow-400 fill-current' : 'text-gray-300'}`}
      />
    ));
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow border border-gray-200 dark:border-gray-700">
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-1">
            {renderStars(review.rating)}
          </div>
          <span className={`px-2 py-1 rounded-full text-xs font-medium ${getSentimentColor(review.sentiment)}`}>
            {review.sentiment}
          </span>
          {review.verified && (
            <CheckCircle className="w-4 h-4 text-blue-600" title="Verified Purchase" />
          )}
        </div>
        
        <div className="flex items-center space-x-2 text-sm text-gray-500 dark:text-gray-400">
          <Globe className="w-4 h-4" />
          <span>{review.language}</span>
        </div>
      </div>

      <div className="mb-4">
        <h4 className="font-medium text-gray-900 dark:text-white mb-1">
          {review.productName}
        </h4>
        <p className="text-sm text-gray-600 dark:text-gray-400">
          by {review.customerName}
        </p>
      </div>

      <div className="mb-4">
        <p className="text-gray-800 dark:text-gray-200 leading-relaxed">
          {review.comment}
        </p>
      </div>

      {review.features && review.features.length > 0 && (
        <div className="mb-4">
          <h5 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
            Feature Analysis:
          </h5>
          <div className="flex flex-wrap gap-2">
            {review.features.map((feature, index) => (
              <span
                key={index}
                className={`px-2 py-1 rounded-full text-xs font-medium ${getSentimentColor(feature.sentiment)}`}
              >
                {feature.feature} ({(feature.score * 100).toFixed(0)}%)
              </span>
            ))}
          </div>
        </div>
      )}

      <div className="flex items-center justify-between text-sm text-gray-500 dark:text-gray-400 pt-4 border-t border-gray-200 dark:border-gray-700">
        <div className="flex items-center space-x-1">
          <MessageSquare className="w-4 h-4" />
          <span>Sentiment Score: {(review.sentimentScore * 100).toFixed(0)}%</span>
        </div>
        <span>{review.timestamp.toLocaleDateString()}</span>
      </div>
    </div>
  );
};