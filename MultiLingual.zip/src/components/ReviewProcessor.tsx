import React, { useState, useRef } from 'react';
import { Upload, FileText, Zap, Brain, Globe, TrendingUp } from 'lucide-react';
import { nlpProcessor, ProcessedReview } from '../services/nlpProcessor';

interface ReviewProcessorProps {
  onProcessedReview: (review: ProcessedReview) => void;
}

export const ReviewProcessor: React.FC<ReviewProcessorProps> = ({ onProcessedReview }) => {
  const [inputText, setInputText] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [lastProcessed, setLastProcessed] = useState<ProcessedReview | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleProcess = async () => {
    if (!inputText.trim()) return;

    setIsProcessing(true);
    
    // Simulate processing delay for better UX
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    try {
      const processed = nlpProcessor.processReview(inputText);
      setLastProcessed(processed);
      onProcessedReview(processed);
    } catch (error) {
      console.error('Error processing review:', error);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file && file.type === 'text/plain') {
      const reader = new FileReader();
      reader.onload = (e) => {
        const content = e.target?.result as string;
        setInputText(content);
      };
      reader.readAsText(file);
    }
  };

  const sampleReviews = [
    "This product is absolutely amazing! The sound quality is crystal clear and the battery lasts all day. Highly recommend!",
    "Muy decepcionado con la calidad de construcción. Se rompió después de una semana de uso.",
    "Le produit est correct mais le prix est un peu élevé pour ce qu'il offre. L'interface utilisateur pourrait être améliorée.",
    "音質は素晴らしいですが、バッテリーの持ちが悪いです。デザインは気に入っています。"
  ];

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
      <div className="flex items-center space-x-2 mb-6">
        <Brain className="w-5 h-5 text-purple-600" />
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
          AI Review Processor
        </h3>
        <div className="flex items-center space-x-1 px-2 py-1 bg-purple-100 dark:bg-purple-900/20 rounded-full">
          <Zap className="w-3 h-3 text-purple-600" />
          <span className="text-xs text-purple-600 font-medium">Real-time NLP</span>
        </div>
      </div>

      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            Enter Review Text
          </label>
          <textarea
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="Paste a customer review in any language..."
            className="w-full h-32 px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white resize-none"
          />
        </div>

        <div className="flex items-center space-x-4">
          <button
            onClick={handleProcess}
            disabled={!inputText.trim() || isProcessing}
            className="flex items-center space-x-2 px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            {isProcessing ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                <span>Processing...</span>
              </>
            ) : (
              <>
                <Brain className="w-4 h-4" />
                <span>Analyze Review</span>
              </>
            )}
          </button>

          <button
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center space-x-2 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
          >
            <Upload className="w-4 h-4" />
            <span>Upload File</span>
          </button>
          
          <input
            ref={fileInputRef}
            type="file"
            accept=".txt"
            onChange={handleFileUpload}
            className="hidden"
          />
        </div>

        <div>
          <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">Quick samples:</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
            {sampleReviews.map((sample, index) => (
              <button
                key={index}
                onClick={() => setInputText(sample)}
                className="text-left p-3 text-sm bg-gray-50 dark:bg-gray-700 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-600 transition-colors"
              >
                {sample.substring(0, 60)}...
              </button>
            ))}
          </div>
        </div>
      </div>

      {lastProcessed && (
        <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-700">
          <h4 className="font-medium text-gray-900 dark:text-white mb-4">Processing Results</h4>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <div className="flex items-center space-x-2 p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
              <Globe className="w-4 h-4 text-blue-600" />
              <div>
                <p className="text-sm font-medium text-blue-900 dark:text-blue-400">Language</p>
                <p className="text-xs text-blue-700 dark:text-blue-300">
                  {lastProcessed.detectedLanguage} ({(lastProcessed.confidence * 100).toFixed(0)}%)
                </p>
              </div>
            </div>
            
            <div className="flex items-center space-x-2 p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
              <TrendingUp className="w-4 h-4 text-green-600" />
              <div>
                <p className="text-sm font-medium text-green-900 dark:text-green-400">Sentiment</p>
                <p className="text-xs text-green-700 dark:text-green-300 capitalize">
                  {lastProcessed.sentiment.label} ({lastProcessed.sentiment.score > 0 ? '+' : ''}{lastProcessed.sentiment.score})
                </p>
              </div>
            </div>
            
            <div className="flex items-center space-x-2 p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
              <FileText className="w-4 h-4 text-purple-600" />
              <div>
                <p className="text-sm font-medium text-purple-900 dark:text-purple-400">Features</p>
                <p className="text-xs text-purple-700 dark:text-purple-300">
                  {lastProcessed.features.length} detected
                </p>
              </div>
            </div>
          </div>

          <div className="space-y-3">
            <div>
              <p className="text-sm font-medium text-gray-700 dark:text-gray-300">Keywords:</p>
              <div className="flex flex-wrap gap-2 mt-1">
                {lastProcessed.keywords.slice(0, 8).map((keyword, index) => (
                  <span
                    key={index}
                    className="px-2 py-1 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 text-xs rounded-full"
                  >
                    {keyword}
                  </span>
                ))}
              </div>
            </div>

            {lastProcessed.features.length > 0 && (
              <div>
                <p className="text-sm font-medium text-gray-700 dark:text-gray-300">Feature Analysis:</p>
                <div className="space-y-2 mt-1">
                  {lastProcessed.features.slice(0, 3).map((feature, index) => (
                    <div key={index} className="flex items-center justify-between p-2 bg-gray-50 dark:bg-gray-700 rounded">
                      <span className="text-sm text-gray-900 dark:text-white">{feature.feature}</span>
                      <span className={`text-xs px-2 py-1 rounded-full ${
                        feature.sentiment === 'positive' ? 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400' :
                        feature.sentiment === 'negative' ? 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400' :
                        'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400'
                      }`}>
                        {feature.sentiment} ({feature.mentions})
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};