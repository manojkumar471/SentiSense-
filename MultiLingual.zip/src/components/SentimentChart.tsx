import React from 'react';
import { TrendingUp, TrendingDown } from 'lucide-react';
import { SentimentTrend } from '../types/feedback';

interface SentimentChartProps {
  data: SentimentTrend[];
}

export const SentimentChart: React.FC<SentimentChartProps> = ({ data }) => {
  const maxValue = Math.max(...data.flatMap(d => [d.positive, d.negative, d.neutral]));
  
  const currentTrend = data[data.length - 1];
  const previousTrend = data[data.length - 2];
  const positiveTrend = currentTrend.positive - previousTrend.positive;
  const negativeTrend = currentTrend.negative - previousTrend.negative;

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
          Sentiment Trends (7 Days)
        </h3>
        <div className="flex space-x-4 text-sm">
          <div className="flex items-center space-x-1">
            {positiveTrend > 0 ? (
              <TrendingUp className="w-4 h-4 text-green-500" />
            ) : (
              <TrendingDown className="w-4 h-4 text-red-500" />
            )}
            <span className={positiveTrend > 0 ? 'text-green-600' : 'text-red-600'}>
              {positiveTrend > 0 ? '+' : ''}{positiveTrend}% Positive
            </span>
          </div>
          <div className="flex items-center space-x-1">
            {negativeTrend < 0 ? (
              <TrendingDown className="w-4 h-4 text-green-500" />
            ) : (
              <TrendingUp className="w-4 h-4 text-red-500" />
            )}
            <span className={negativeTrend < 0 ? 'text-green-600' : 'text-red-600'}>
              {negativeTrend > 0 ? '+' : ''}{negativeTrend}% Negative
            </span>
          </div>
        </div>
      </div>

      <div className="relative h-64">
        <div className="absolute inset-0 flex items-end justify-between space-x-1">
          {data.map((trend, index) => (
            <div key={trend.date} className="flex flex-col items-center flex-1">
              <div className="w-full flex flex-col space-y-1 items-end mb-2">
                <div
                  className="w-full bg-green-500 rounded-sm opacity-80 hover:opacity-100 transition-opacity"
                  style={{ height: `${(trend.positive / maxValue) * 100}%` }}
                  title={`Positive: ${trend.positive}%`}
                />
                <div
                  className="w-full bg-yellow-500 rounded-sm opacity-80 hover:opacity-100 transition-opacity"
                  style={{ height: `${(trend.neutral / maxValue) * 100}%` }}
                  title={`Neutral: ${trend.neutral}%`}
                />
                <div
                  className="w-full bg-red-500 rounded-sm opacity-80 hover:opacity-100 transition-opacity"
                  style={{ height: `${(trend.negative / maxValue) * 100}%` }}
                  title={`Negative: ${trend.negative}%`}
                />
              </div>
              <span className="text-xs text-gray-500 dark:text-gray-400 transform -rotate-45 origin-left">
                {new Date(trend.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
              </span>
            </div>
          ))}
        </div>
      </div>

      <div className="flex justify-center space-x-6 mt-6 pt-4 border-t border-gray-200 dark:border-gray-700">
        <div className="flex items-center space-x-2">
          <div className="w-3 h-3 bg-green-500 rounded-full"></div>
          <span className="text-sm text-gray-600 dark:text-gray-400">Positive</span>
        </div>
        <div className="flex items-center space-x-2">
          <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
          <span className="text-sm text-gray-600 dark:text-gray-400">Neutral</span>
        </div>
        <div className="flex items-center space-x-2">
          <div className="w-3 h-3 bg-red-500 rounded-full"></div>
          <span className="text-sm text-gray-600 dark:text-gray-400">Negative</span>
        </div>
      </div>
    </div>
  );
};