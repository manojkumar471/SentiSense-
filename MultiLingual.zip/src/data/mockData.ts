import { Review, SentimentTrend, LanguageStats, Alert } from '../types/feedback';

export const mockReviews: Review[] = [
  {
    id: '1',
    productId: 'prod-1',
    productName: 'Wireless Bluetooth Headphones',
    customerName: 'Maria González',
    rating: 5,
    comment: 'Excelente calidad de audio y muy cómodos para uso prolongado.',
    language: 'Spanish',
    languageCode: 'es',
    sentiment: 'positive',
    sentimentScore: 0.92,
    features: [
      { feature: 'Audio Quality', sentiment: 'positive', score: 0.95, mentions: 1 },
      { feature: 'Comfort', sentiment: 'positive', score: 0.88, mentions: 1 }
    ],
    timestamp: new Date('2024-01-15T10:30:00'),
    verified: true
  },
  {
    id: '2',
    productId: 'prod-1',
    productName: 'Wireless Bluetooth Headphones',
    customerName: 'John Smith',
    rating: 2,
    comment: 'Battery life is disappointing, only lasts 3 hours instead of advertised 8 hours.',
    language: 'English',
    languageCode: 'en',
    sentiment: 'negative',
    sentimentScore: -0.78,
    features: [
      { feature: 'Battery Life', sentiment: 'negative', score: -0.85, mentions: 1 }
    ],
    timestamp: new Date('2024-01-15T14:22:00'),
    verified: true
  },
  {
    id: '3',
    productId: 'prod-2',
    productName: 'Smart Fitness Watch',
    customerName: 'François Dubois',
    rating: 4,
    comment: 'Très bon produit avec de nombreuses fonctionnalités. L\'écran pourrait être plus lumineux.',
    language: 'French',
    languageCode: 'fr',
    sentiment: 'positive',
    sentimentScore: 0.65,
    features: [
      { feature: 'Features', sentiment: 'positive', score: 0.85, mentions: 1 },
      { feature: 'Display', sentiment: 'negative', score: -0.45, mentions: 1 }
    ],
    timestamp: new Date('2024-01-15T16:45:00'),
    verified: true
  },
  {
    id: '4',
    productId: 'prod-3',
    productName: 'Gaming Mechanical Keyboard',
    customerName: 'Hiroshi Tanaka',
    rating: 5,
    comment: 'キーの反応が素晴らしく、ゲームに最適です。RGB照明も美しいです。',
    language: 'Japanese',
    languageCode: 'ja',
    sentiment: 'positive',
    sentimentScore: 0.89,
    features: [
      { feature: 'Key Response', sentiment: 'positive', score: 0.92, mentions: 1 },
      { feature: 'RGB Lighting', sentiment: 'positive', score: 0.86, mentions: 1 }
    ],
    timestamp: new Date('2024-01-15T18:12:00'),
    verified: true
  },
  {
    id: '5',
    productId: 'prod-1',
    productName: 'Wireless Bluetooth Headphones',
    customerName: 'Ahmed Hassan',
    rating: 3,
    comment: 'جودة الصوت جيدة لكن التصميم يمكن أن يكون أفضل',
    language: 'Arabic',
    languageCode: 'ar',
    sentiment: 'neutral',
    sentimentScore: 0.15,
    features: [
      { feature: 'Audio Quality', sentiment: 'positive', score: 0.7, mentions: 1 },
      { feature: 'Design', sentiment: 'negative', score: -0.4, mentions: 1 }
    ],
    timestamp: new Date('2024-01-15T20:30:00'),
    verified: false
  }
];

export const sentimentTrends: SentimentTrend[] = [
  { date: '2024-01-09', positive: 65, negative: 20, neutral: 15 },
  { date: '2024-01-10', positive: 70, negative: 18, neutral: 12 },
  { date: '2024-01-11', positive: 68, negative: 22, neutral: 10 },
  { date: '2024-01-12', positive: 72, negative: 16, neutral: 12 },
  { date: '2024-01-13', positive: 66, negative: 25, neutral: 9 },
  { date: '2024-01-14', positive: 74, negative: 15, neutral: 11 },
  { date: '2024-01-15', positive: 69, negative: 19, neutral: 12 }
];

export const languageStats: LanguageStats[] = [
  { language: 'English', code: 'en', count: 1247, percentage: 42.3, avgSentiment: 0.65 },
  { language: 'Spanish', code: 'es', count: 892, percentage: 30.2, avgSentiment: 0.72 },
  { language: 'French', code: 'fr', count: 356, percentage: 12.1, avgSentiment: 0.58 },
  { language: 'German', code: 'de', count: 234, percentage: 7.9, avgSentiment: 0.61 },
  { language: 'Japanese', code: 'ja', count: 156, percentage: 5.3, avgSentiment: 0.78 },
  { language: 'Arabic', code: 'ar', count: 65, percentage: 2.2, avgSentiment: 0.45 }
];

export const alerts: Alert[] = [
  {
    id: 'alert-1',
    type: 'negative_trend',
    severity: 'high',
    title: 'Negative Sentiment Spike',
    description: 'Battery life complaints increased by 45% in the last 24 hours',
    productId: 'prod-1',
    timestamp: new Date('2024-01-15T15:30:00'),
    resolved: false
  },
  {
    id: 'alert-2',
    type: 'feature_issue',
    severity: 'medium',
    title: 'Display Brightness Issues',
    description: 'Multiple French reviews mention display brightness problems',
    productId: 'prod-2',
    timestamp: new Date('2024-01-15T12:15:00'),
    resolved: false
  },
  {
    id: 'alert-3',
    type: 'low_rating',
    severity: 'low',
    title: 'Rating Drop Alert',
    description: 'Average rating dropped to 3.2 stars for this product',
    productId: 'prod-4',
    timestamp: new Date('2024-01-15T09:45:00'),
    resolved: true
  }
];