import { franc } from 'franc';
import Sentiment from 'sentiment';
import { removeStopwords, eng, spa, fra, deu, jpn, ara } from 'stopword';
import nlp from 'compromise';

export interface ProcessedReview {
  originalText: string;
  detectedLanguage: string;
  languageCode: string;
  confidence: number;
  sentiment: {
    label: 'positive' | 'negative' | 'neutral';
    score: number;
    comparative: number;
  };
  keywords: string[];
  entities: {
    people: string[];
    places: string[];
    organizations: string[];
  };
  features: FeatureAnalysis[];
  emotions: EmotionAnalysis;
  readabilityScore: number;
}

export interface FeatureAnalysis {
  feature: string;
  sentiment: 'positive' | 'negative' | 'neutral';
  score: number;
  mentions: number;
  keywords: string[];
  context: string[];
}

export interface EmotionAnalysis {
  joy: number;
  anger: number;
  fear: number;
  sadness: number;
  surprise: number;
  disgust: number;
}

class NLPProcessor {
  private sentiment: any;
  private productFeatures: { [key: string]: string[] };
  private emotionKeywords: { [key: string]: string[] };

  constructor() {
    this.sentiment = new Sentiment();
    
    // Define product features and their related keywords
    this.productFeatures = {
      'Audio Quality': ['sound', 'audio', 'music', 'bass', 'treble', 'clarity', 'volume', 'noise', 'crisp', 'clear'],
      'Battery Life': ['battery', 'charge', 'charging', 'power', 'lasted', 'drain', 'hours', 'days', 'life'],
      'Design': ['design', 'look', 'appearance', 'style', 'color', 'beautiful', 'ugly', 'aesthetic', 'sleek'],
      'Comfort': ['comfort', 'comfortable', 'fit', 'ergonomic', 'painful', 'hurt', 'soft', 'cushion', 'wear'],
      'Build Quality': ['quality', 'build', 'construction', 'durable', 'sturdy', 'cheap', 'flimsy', 'solid', 'materials'],
      'Price Value': ['price', 'cost', 'value', 'money', 'expensive', 'cheap', 'worth', 'affordable', 'overpriced'],
      'Connectivity': ['bluetooth', 'wifi', 'connection', 'connect', 'pair', 'disconnect', 'signal', 'range'],
      'User Interface': ['interface', 'ui', 'menu', 'navigation', 'buttons', 'controls', 'easy', 'difficult', 'intuitive'],
      'Performance': ['performance', 'speed', 'fast', 'slow', 'lag', 'responsive', 'smooth', 'quick', 'efficient'],
      'Display': ['screen', 'display', 'bright', 'dim', 'resolution', 'pixels', 'clear', 'blurry', 'sharp']
    };

    this.emotionKeywords = {
      joy: ['happy', 'joy', 'excited', 'pleased', 'satisfied', 'delighted', 'thrilled', 'amazing', 'wonderful', 'fantastic'],
      anger: ['angry', 'frustrated', 'annoyed', 'irritated', 'mad', 'furious', 'outraged', 'terrible', 'awful', 'horrible'],
      fear: ['worried', 'concerned', 'afraid', 'scared', 'anxious', 'nervous', 'uncertain', 'doubtful'],
      sadness: ['sad', 'disappointed', 'unhappy', 'depressed', 'upset', 'regret', 'sorry', 'unfortunate'],
      surprise: ['surprised', 'shocked', 'amazed', 'unexpected', 'wow', 'incredible', 'unbelievable'],
      disgust: ['disgusted', 'gross', 'awful', 'terrible', 'horrible', 'nasty', 'revolting']
    };
  }

  detectLanguage(text: string): { language: string; code: string; confidence: number } {
    const langCode = franc(text);
    const languageMap: { [key: string]: string } = {
      'eng': 'English',
      'spa': 'Spanish',
      'fra': 'French',
      'deu': 'German',
      'jpn': 'Japanese',
      'ara': 'Arabic',
      'ita': 'Italian',
      'por': 'Portuguese',
      'rus': 'Russian',
      'kor': 'Korean',
      'chi': 'Chinese',
      'hin': 'Hindi'
    };

    const language = languageMap[langCode] || 'Unknown';
    const confidence = langCode !== 'und' ? 0.85 : 0.3;

    return {
      language,
      code: langCode,
      confidence
    };
  }

  analyzeSentiment(text: string): { label: 'positive' | 'negative' | 'neutral'; score: number; comparative: number } {
    const result = this.sentiment.analyze(text);
    
    let label: 'positive' | 'negative' | 'neutral';
    if (result.score > 0) {
      label = 'positive';
    } else if (result.score < 0) {
      label = 'negative';
    } else {
      label = 'neutral';
    }

    return {
      label,
      score: result.score,
      comparative: result.comparative
    };
  }

  extractKeywords(text: string, languageCode: string): string[] {
    const doc = nlp(text);
    
    // Extract nouns, adjectives, and important verbs
    const nouns = doc.nouns().out('array');
    const adjectives = doc.adjectives().out('array');
    const verbs = doc.verbs().out('array').filter((verb: string) => 
      ['love', 'hate', 'like', 'dislike', 'recommend', 'avoid'].includes(verb.toLowerCase())
    );

    let allWords = [...nouns, ...adjectives, ...verbs]
      .map(word => word.toLowerCase())
      .filter(word => word.length > 2);

    // Remove stopwords based on detected language
    const stopwordLang = this.getStopwordLanguage(languageCode);
    if (stopwordLang) {
      allWords = removeStopwords(allWords, stopwordLang);
    }

    // Get unique keywords and sort by frequency
    const wordFreq: { [key: string]: number } = {};
    allWords.forEach(word => {
      wordFreq[word] = (wordFreq[word] || 0) + 1;
    });

    return Object.entries(wordFreq)
      .sort(([,a], [,b]) => b - a)
      .slice(0, 10)
      .map(([word]) => word);
  }

  extractEntities(text: string): { people: string[]; places: string[]; organizations: string[] } {
    const doc = nlp(text);
    
    return {
      people: doc.people().out('array'),
      places: doc.places().out('array'),
      organizations: doc.organizations().out('array')
    };
  }

  analyzeFeatures(text: string, sentiment: any): FeatureAnalysis[] {
    const features: FeatureAnalysis[] = [];
    const lowerText = text.toLowerCase();
    const doc = nlp(text);

    Object.entries(this.productFeatures).forEach(([featureName, keywords]) => {
      const mentions = keywords.filter(keyword => lowerText.includes(keyword.toLowerCase()));
      
      if (mentions.length > 0) {
        // Extract sentences containing feature keywords
        const sentences = text.split(/[.!?]+/).filter(sentence => 
          mentions.some(mention => sentence.toLowerCase().includes(mention.toLowerCase()))
        );

        // Analyze sentiment for feature-specific context
        const featureText = sentences.join(' ');
        const featureSentiment = this.sentiment.analyze(featureText);
        
        let sentimentLabel: 'positive' | 'negative' | 'neutral';
        if (featureSentiment.score > 0) {
          sentimentLabel = 'positive';
        } else if (featureSentiment.score < 0) {
          sentimentLabel = 'negative';
        } else {
          sentimentLabel = 'neutral';
        }

        features.push({
          feature: featureName,
          sentiment: sentimentLabel,
          score: featureSentiment.comparative,
          mentions: mentions.length,
          keywords: mentions,
          context: sentences.slice(0, 2) // First 2 relevant sentences
        });
      }
    });

    return features.sort((a, b) => b.mentions - a.mentions);
  }

  analyzeEmotions(text: string): EmotionAnalysis {
    const lowerText = text.toLowerCase();
    const emotions: EmotionAnalysis = {
      joy: 0,
      anger: 0,
      fear: 0,
      sadness: 0,
      surprise: 0,
      disgust: 0
    };

    Object.entries(this.emotionKeywords).forEach(([emotion, keywords]) => {
      const matches = keywords.filter(keyword => lowerText.includes(keyword));
      emotions[emotion as keyof EmotionAnalysis] = matches.length;
    });

    // Normalize scores
    const total = Object.values(emotions).reduce((sum, score) => sum + score, 0);
    if (total > 0) {
      Object.keys(emotions).forEach(emotion => {
        emotions[emotion as keyof EmotionAnalysis] = 
          emotions[emotion as keyof EmotionAnalysis] / total;
      });
    }

    return emotions;
  }

  calculateReadabilityScore(text: string): number {
    const sentences = text.split(/[.!?]+/).length;
    const words = text.split(/\s+/).length;
    const syllables = this.countSyllables(text);

    // Flesch Reading Ease Score
    const score = 206.835 - (1.015 * (words / sentences)) - (84.6 * (syllables / words));
    return Math.max(0, Math.min(100, score));
  }

  private countSyllables(text: string): number {
    return text.toLowerCase()
      .replace(/[^a-z]/g, '')
      .replace(/[aeiouy]+/g, 'a')
      .replace(/a$/, '')
      .length || 1;
  }

  private getStopwordLanguage(langCode: string): any {
    const langMap: { [key: string]: any } = {
      'eng': eng,
      'spa': spa,
      'fra': fra,
      'deu': deu,
      'jpn': jpn,
      'ara': ara
    };
    return langMap[langCode];
  }

  processReview(text: string): ProcessedReview {
    const languageInfo = this.detectLanguage(text);
    const sentimentInfo = this.analyzeSentiment(text);
    const keywords = this.extractKeywords(text, languageInfo.code);
    const entities = this.extractEntities(text);
    const features = this.analyzeFeatures(text, sentimentInfo);
    const emotions = this.analyzeEmotions(text);
    const readabilityScore = this.calculateReadabilityScore(text);

    return {
      originalText: text,
      detectedLanguage: languageInfo.language,
      languageCode: languageInfo.code,
      confidence: languageInfo.confidence,
      sentiment: sentimentInfo,
      keywords,
      entities,
      features,
      emotions,
      readabilityScore
    };
  }
}

export const nlpProcessor = new NLPProcessor();