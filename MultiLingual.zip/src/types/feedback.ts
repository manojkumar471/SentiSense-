export interface Review {
  id: string;
  productId: string;
  productName: string;
  customerName: string;
  rating: number;
  comment: string;
  language: string;
  languageCode: string;
  sentiment: 'positive' | 'negative' | 'neutral';
  sentimentScore: number;
  features: FeatureRating[];
  timestamp: Date;
  verified: boolean;
}

export interface FeatureRating {
  feature: string;
  sentiment: 'positive' | 'negative' | 'neutral';
  score: number;
  mentions: number;
}

export interface SentimentTrend {
  date: string;
  positive: number;
  negative: number;
  neutral: number;
}

export interface LanguageStats {
  language: string;
  code: string;
  count: number;
  percentage: number;
  avgSentiment: number;
}

export interface Alert {
  id: string;
  type: 'negative_trend' | 'low_rating' | 'feature_issue';
  severity: 'high' | 'medium' | 'low';
  title: string;
  description: string;
  productId: string;
  timestamp: Date;
  resolved: boolean;
}